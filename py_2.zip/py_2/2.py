import warnings

warnings.filterwarnings("ignore", category=UserWarning, module="tkinter")
import os
import numpy as np
import wave
from scipy.io import wavfile
from python_speech_features import mfcc
from hmmlearn.hmm import GMMHMM
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from ttkbootstrap import Style
from ttkbootstrap.constants import *

import pyaudio
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg


# 提取 MFCC 特征
def extract_features(file_path):
    sample_rate, signal = wavfile.read(file_path)  #使用 scipy.io.wavfile.read 函数来读取音频文件返回音频文件的采样信号和音频的采样频率
    features = mfcc(signal, sample_rate, numcep=13, nfft=1200)  #python_speech_features 库中的 mfcc 函数来提取 MFCC 特征
    return features  #返回的 features 可能是一个大小为 (N, 13) 的数组，其中 N 是音频文件的帧数（取决于音频的长度和帧大小）。每行的 13 个数字对应于该帧的 13 个 MFCC 系数。返回的 features 可能是一个大小为 (N, 13) 的数组，其中 N 是音频文件的帧数（取决于音频的长度和帧大小）。每行的 13 个数字对应于该帧的 13 个 MFCC 系数。


# 读取数据
def load_data(data_dir):  #包含训练数据的根目录
    data = {}
    for label in os.listdir(data_dir):  #遍历 data_dir 目录
        label_dir = os.path.join(data_dir, label)
        if os.path.isdir(label_dir):   #判断是否是子目录
            features = []
            for file in os.listdir(label_dir):
                if file.endswith('.wav'):
                    file_path = os.path.join(label_dir, file)  #遍历该目录下的 .wav 文件
                    features.append(extract_features(file_path))#提取特征
            data[label] = features
    return data   #所有该标签下的音频特征都会存储在 data 字典


# 训练 HMM-GMM 模型
def train_hmm_gmm(data):      #上一个函数的输出
    models = {}   #字典，键是标签，值是训练好的 GMM-HMM 模型。
    for label, features_list in data.items():         #遍历输入数据集 data
        all_features = np.vstack(features_list)      #将当前类别的所有特征矩阵通过 np.vstack 纵向拼接为一个矩阵。
        lengths = [len(features) for features in features_list]   #计算每个样本（音频）的帧数，并存储为列表 lengths

        model = GMMHMM(n_components=5, n_mix=5, covariance_type='diag', n_iter=200)    #创建一个 GMM-HMM 模型实例
        model.fit(all_features, lengths)          #对当前类别的 GMM-HMM 模型进行训练

        models[label] = model         #GMM 使用 EM 算法调整混合分布的参数
    return models            #HMM 使用 Baum-Welch 算法估计隐状态参数

   #n_components=5:隐状态数通常与语音结构相关（如发音的主要声学单元）
#n_mix=5每个隐状态的 GMM 混合数，控制单状态建模的复杂度
#covariance_type='diag'协方差类型为对角矩阵，假设特征之间无相关性
#n_iter=200:EM 算法最大迭代次数







# 识别单词
def recognize(models, test_file):
    test_features = extract_features(test_file)      #提取测试音频的特征
    scores = {}
    for label, model in models.items():     #遍历 models 中的每个类别及其对应的 HMM-GMM 模型。
        scores[label] = model.score(test_features)      #model.score(test_features) 计算模型对输入特征的得分
    return max(scores, key=scores.get)         #key=scores.get 指定按照字典值（即得分）进行排序。


# 录音功能
def record_audio(output_file, record_seconds=5, sample_rate=16000, show_progress=None):
    chunk = 1024
    format = pyaudio.paInt16
    channels = 1

    p = pyaudio.PyAudio()

    stream = p.open(format=format,
                    channels=channels,
                    rate=sample_rate,
                    input=True,
                    frames_per_buffer=chunk)      #创建音频流，用于从麦克风中实时读取音频

    frames = []
    for i in range(0, int(sample_rate / chunk * record_seconds)):        #录制音频帧
        data = stream.read(chunk)
        frames.append(data)

        # 显示实时进度
        if show_progress:
            progress = (i + 1) / (sample_rate / chunk * record_seconds) * 100
            show_progress(progress)

    stream.stop_stream()        #关闭流并保存文件
    stream.close()
    p.terminate()

    wf = wave.open(output_file, 'wb')
    wf.setnchannels(channels)
    wf.setsampwidth(p.get_sample_size(format))
    wf.setframerate(sample_rate)
    wf.writeframes(b''.join(frames))
    wf.close()


# GUI 界面
class WordRecognitionApp:
    def __init__(self, root):
        self.root = root
        self.root.title("语音识别系统")
        style = Style(theme="cosmo")  # 使用 ttkbootstrap 的主题,可选主题：cosmo、darkly、flatly、journal 等
        self.models = None

        # 创建主界面布局
        ttk.Label(root, text="语音识别系统", font=("Arial", 20, "bold"), bootstyle=PRIMARY).pack(pady=10)

        # 训练模型
        ttk.Button(root, text="训练模型", command=self.train_models, bootstyle=INFO).pack(pady=10)

        # 实时录音
        self.record_frame = ttk.Frame(root, padding=10)
        self.record_frame.pack(pady=10)
        ttk.Label(self.record_frame, text="录音时长 (秒)：", bootstyle=SECONDARY).grid(row=0, column=0, padx=5)
        self.record_slider = ttk.Scale(self.record_frame, from_=1, to=10, orient="horizontal", length=200)
        self.record_slider.set(5)
        self.record_slider.grid(row=0, column=1, padx=5)
        ttk.Button(self.record_frame, text="录音并识别", command=self.record_and_recognize, bootstyle=SUCCESS).grid(
            row=0, column=2, padx=5)

        # 波形显示
        self.figure, self.ax = plt.subplots(figsize=(5, 2))
        self.ax.set_title("实时音频波形")
        self.ax.set_xlabel("时间")
        self.ax.set_ylabel("幅  ")
        self.canvas = FigureCanvasTkAgg(self.figure, root)
        self.canvas.get_tk_widget().pack(pady=10)

        # 批量识别
        ttk.Button(root, text="批量识别", command=self.batch_recognize, bootstyle=WARNING).pack(pady=10)

        # 单个文件识别
        ttk.Button(root, text="单个文件识别", command=self.single_recognize, bootstyle=DANGER).pack(pady=10)

        # 识别结果
        self.result_label = ttk.Label(root, text="", font=("Arial", 16), bootstyle=SUCCESS)
        self.result_label.pack(pady=20)

    def update_progress(self, progress):
        self.ax.clear()
        self.ax.plot(np.sin(np.linspace(0, 2 * np.pi, int(progress))))
        self.canvas.draw()

    def train_models(self):
        data_dir = filedialog.askdirectory(title="选择训练数据目录")
        if not data_dir:
            return

        messagebox.showinfo("模型训练", "正在训练模型，请稍候...")
        data = load_data(data_dir)
        self.models = train_hmm_gmm(data)
        messagebox.showinfo("模型训练", "模型训练完成！")

    def record_and_recognize(self):
        if not self.models:
            messagebox.showerror("错误", "请先训练模型！")
            return

        output_file = "recorded_audio.wav"
        record_seconds = int(self.record_slider.get())
        record_audio(output_file, record_seconds, show_progress=self.update_progress)

        recognized_word = recognize(self.models, output_file)
        self.result_label.config(text=f"识别结果: {recognized_word}")

    def batch_recognize(self):
        if not self.models:
            messagebox.showerror("错误", "请先训练模型！")
            return

        data_dir = filedialog.askdirectory(title="选择测试音频目录")
        if not data_dir:
            return

        results = {}
        for file in os.listdir(data_dir):
            if file.endswith('.wav'):
                file_path = os.path.join(data_dir, file)
                results[file] = recognize(self.models, file_path)

        result_str = "\n".join([f"{file}: {word}" for file, word in results.items()])
        messagebox.showinfo("批量识别结果", result_str)

    def single_recognize(self):
        if not self.models:
            messagebox.showerror("错误", "请先训练模型！")
            return

        file_path = filedialog.askopenfilename(title="选择音频文件", filetypes=[("WAV Files", "*.wav")])
        if not file_path:
            return

        recognized_word = recognize(self.models, file_path)
        self.result_label.config(text=f"识别结果: {recognized_word}")


# 主程序入口
if __name__ == "__main__":
    root = tk.Tk()
    app = WordRecognitionApp(root)
    root.mainloop()
